const loginForm = document.getElementById("adminLoginForm");
const loginError = document.getElementById("loginError");

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginError.classList.add("hidden");

  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value.trim();

  const result = await loginAdmin(email, password);

  if (result.twofaRequired) {
    // store temporarily so we can replay full login with 2FA code
    sessionStorage.setItem("2fa_email", email);
    sessionStorage.setItem("2fa_password", password);

    window.location.href = "admin-2fa.html";
    return;
  }

  if (result.success) {
    window.location.href = "admin-dashboard.html";
  } else {
    loginError.textContent = result.error || "Invalid credentials.";
    loginError.classList.remove("hidden");
  }
});
