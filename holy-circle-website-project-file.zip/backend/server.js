import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import speakeasy from "speakeasy";
import crypto from "crypto";
import db from "./db.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || "http://localhost:5500";
const JWT_SECRET = process.env.JWT_SECRET;

// Middleware
app.use(express.json());
app.use(cookieParser());
app.use(
  cors({
    origin: CLIENT_ORIGIN,
    credentials: true,
  })
);

// Helper: create JWT
function createToken(user) {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role,
    },
    JWT_SECRET,
    { expiresIn: "2h" }
  );
}

// Middleware: auth protect
function authRequired(req, res, next) {
  const token = req.cookies["hc_admin_token"];
  if (!token) return res.status(401).json({ error: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ error: "Invalid token" });
  }
}

// Helper: get user by email
function getUserByEmail(email) {
  return new Promise((resolve, reject) => {
    db.get("SELECT * FROM users WHERE email = ?", [email], (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

// Helper: update failed attempts
function updateFailedAttempt(user, success) {
  return new Promise((resolve, reject) => {
    if (success) {
      db.run(
        "UPDATE users SET failed_attempts = 0, lock_until = NULL WHERE id = ?",
        [user.id],
        (err) => (err ? reject(err) : resolve())
      );
    } else {
      const now = Date.now();
      let failed = (user.failed_attempts || 0) + 1;
      let lockUntil = user.lock_until;

      // Lock after 5 failed attempts for 15 minutes
      if (failed >= 5) {
        lockUntil = now + 15 * 60 * 1000;
      }

      db.run(
        "UPDATE users SET failed_attempts = ?, lock_until = ? WHERE id = ?",
        [failed, lockUntil, user.id],
        (err) => (err ? reject(err) : resolve())
      );
    }
  });
}

// ========= ROUTES ==========

// Registration (for now: open; in real world gate this)
app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password required." });
    }

    const existing = await getUserByEmail(email);
    if (existing) {
      return res.status(400).json({ error: "Email already registered." });
    }

    const hash = await bcrypt.hash(password, 10);
    const now = Date.now();

    db.run(
      "INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)",
      [name || "", email, hash, role || "admin", now],
      function (err) {
        if (err) return res.status(500).json({ error: "DB error" });

        const user = {
          id: this.lastID,
          email,
          role: role || "admin",
        };
        const token = createToken(user);

        res
          .cookie("hc_admin_token", token, {
            httpOnly: true,
            sameSite: "lax",
            secure: false, // set true in production with HTTPS
          })
          .json({ message: "Registered", user });
      }
    );
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Server error" });
  }
});

// Login
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password, twofaCode } = req.body;
    const user = await getUserByEmail(email);
    if (!user) return res.status(400).json({ error: "Invalid credentials" });

    const now = Date.now();
    if (user.lock_until && now < user.lock_until) {
      return res.status(423).json({
        error: "Account locked due to failed attempts. Try again later.",
      });
    }

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      await updateFailedAttempt(user, false);
      return res.status(400).json({ error: "Invalid credentials" });
    }

    // If 2FA enabled, require code
    if (user.twofa_enabled) {
      if (!twofaCode) {
        return res.status(200).json({ twofaRequired: true });
      }

      const verified = speakeasy.totp.verify({
        secret: user.twofa_secret,
        encoding: "base32",
        token: twofaCode,
        window: 1,
      });

      if (!verified) {
        return res.status(400).json({ error: "Invalid 2FA code" });
      }
    }

    await updateFailedAttempt(user, true);

    const token = createToken(user);

    res
      .cookie("hc_admin_token", token, {
        httpOnly: true,
        sameSite: "lax",
        secure: false,
      })
      .json({
        message: "Logged in",
        user: { id: user.id, email: user.email, role: user.role },
      });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Server error" });
  }
});

// Me (used by frontend to check auth)
app.get("/api/auth/me", authRequired, (req, res) => {
  db.get(
    "SELECT id, email, role, name FROM users WHERE id = ?",
    [req.user.id],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: "User not found" });
      res.json({ user: row });
    }
  );
});

// Logout
app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("hc_admin_token").json({ message: "Logged out" });
});

// Enable 2FA (returns secret + otpauth url)
app.post("/api/auth/2fa/setup", authRequired, (req, res) => {
  const secret = speakeasy.generateSecret({
    name: "Holy Circle Admin",
  });

  db.run(
    "UPDATE users SET twofa_secret = ?, twofa_enabled = 0 WHERE id = ?",
    [secret.base32, req.user.id],
    (err) => {
      if (err) return res.status(500).json({ error: "DB error" });

      res.json({
        secret: secret.base32,
        otpauth_url: secret.otpauth_url,
      });
    }
  );
});

// Confirm 2FA (user enters a token from app)
app.post("/api/auth/2fa/confirm", authRequired, (req, res) => {
  const { token } = req.body;

  db.get(
    "SELECT twofa_secret FROM users WHERE id = ?",
    [req.user.id],
    (err, user) => {
      if (err || !user || !user.twofa_secret) {
        return res.status(400).json({ error: "No 2FA setup found" });
      }

      const verified = speakeasy.totp.verify({
        secret: user.twofa_secret,
        encoding: "base32",
        token,
        window: 1,
      });

      if (!verified) {
        return res.status(400).json({ error: "Invalid 2FA token" });
      }

      db.run(
        "UPDATE users SET twofa_enabled = 1 WHERE id = ?",
        [req.user.id],
        (err2) => {
          if (err2) return res.status(500).json({ error: "DB error" });
          res.json({ message: "2FA enabled" });
        }
      );
    }
  );
});

// Request password reset (generate token)
// NOTE: For now we just log the token to console. You’ll email later.
app.post("/api/auth/request-reset", (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: "Email required" });

  db.get("SELECT id FROM users WHERE email = ?", [email], (err, user) => {
    if (err) return res.status(500).json({ error: "DB error" });
    if (!user) return res.json({ message: "If account exists, email sent." });

    const token = crypto.randomBytes(32).toString("hex");
    const expires = Date.now() + 60 * 60 * 1000; // 1 hour

    db.run(
      "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)",
      [user.id, token, expires],
      (err2) => {
        if (err2) return res.status(500).json({ error: "DB error" });

        console.log(
          "Password reset link (dev mode):",
          `${CLIENT_ORIGIN}/admin-reset-password.html?token=${token}`
        );

        res.json({ message: "If account exists, email sent." });
      }
    );
  });
});

// Reset password
app.post("/api/auth/reset-password", (req, res) => {
  const { token, password } = req.body;
  if (!token || !password) {
    return res.status(400).json({ error: "Token and new password required." });
  }

  db.get(
    "SELECT * FROM password_resets WHERE token = ? AND used = 0",
    [token],
    async (err, row) => {
      if (err || !row) {
        return res.status(400).json({ error: "Invalid or used token." });
      }

      if (Date.now() > row.expires_at) {
        return res.status(400).json({ error: "Token expired." });
      }

      const hash = await bcrypt.hash(password, 10);

      db.run(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        [hash, row.user_id],
        (err2) => {
          if (err2) return res.status(500).json({ error: "DB error" });

          db.run(
            "UPDATE password_resets SET used = 1 WHERE id = ?",
            [row.id],
            (err3) => {
              if (err3) return res.status(500).json({ error: "DB error" });
              res.json({ message: "Password updated." });
            }
          );
        }
      );
    }
  );
});

// Start server
app.listen(PORT, () => {
  console.log(`Holy Circle admin backend running on http://localhost:${PORT}`);
});

app.get("/api/admin/users", authRequired, (req, res) => {
    db.all(
      "SELECT id, name, email, role, twofa_enabled, created_at FROM users",
      (err, rows) => {
        if (err) return res.status(500).json({ error: "DB error" });
        res.json({ users: rows });
      }
    );
  });
  app.get("/api/admin/users/:id", authRequired, (req, res) => {
    db.get(
      "SELECT id, name, email, role FROM users WHERE id = ?",
      [req.params.id],
      (err, row) => {
        if (err || !row) return res.status(404).json({ error: "Not found" });
        res.json({ user: row });
      }
    );
  });
  app.post("/api/admin/users", authRequired, async (req, res) => {
    const { name, email, role, password } = req.body;
  
    if (!password)
      return res.status(400).json({ error: "Password required." });
  
    const hash = await bcrypt.hash(password, 10);
  
    db.run(
      "INSERT INTO users (name, email, role, password_hash, created_at) VALUES (?, ?, ?, ?, ?)",
      [name, email, role, hash, Date.now()],
      function (err) {
        if (err) return res.status(500).json({ error: "Email already exists" });
        res.json({ id: this.lastID });
      }
    );
  });
  app.put("/api/admin/users/:id", authRequired, async (req, res) => {
    const { name, email, role, password } = req.body;
  
    let query, params;
  
    if (password) {
      const hash = await bcrypt.hash(password, 10);
      query = "UPDATE users SET name=?, email=?, role=?, password_hash=? WHERE id=?";
      params = [name, email, role, hash, req.params.id];
    } else {
      query = "UPDATE users SET name=?, email=?, role=? WHERE id=?";
      params = [name, email, role, req.params.id];
    }
  
    db.run(query, params, (err) => {
      if (err) return res.status(500).json({ error: "DB error" });
      res.json({ updated: true });
    });
  });
  app.delete("/api/admin/users/:id", authRequired, (req, res) => {
    db.run(
      "DELETE FROM users WHERE id = ?",
      [req.params.id],
      (err) => {
        if (err) return res.status(500).json({ error: "DB error" });
        res.json({ deleted: true });
      }
    );
  });
  
  app.get("/api/settings", authRequired, (req, res) => {
    db.get("SELECT * FROM settings WHERE id = 1", (err, row) => {
      if (!row) {
        return res.json({
          ministryName: "",
          websiteURL: "",
          supportEmail: "",
          timezone: "UTC"
        });
      }
      res.json(row);
    });
  });
  app.post("/api/settings/general", authRequired, (req, res) => {
    const { ministryName, websiteURL, supportEmail, timezone } = req.body;
  
    db.run(`
      INSERT INTO settings (id, ministryName, websiteURL, supportEmail, timezone)
      VALUES (1, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        ministryName = excluded.ministryName,
        websiteURL = excluded.websiteURL,
        supportEmail = excluded.supportEmail,
        timezone = excluded.timezone
    `,
    [ministryName, websiteURL, supportEmail, timezone],
    (err) => {
      if (err) return res.status(500).json({ error: "DB error" });
      res.json({ saved: true });
    });
  });
  app.post("/api/settings/password", authRequired, async (req, res) => {
    const { currentPassword, newPassword } = req.body;
  
    db.get("SELECT * FROM users WHERE id = ?", [req.user.id], async (err, row) => {
      if (!row) return res.status(404).json({ error: "User not found" });
  
      const valid = await bcrypt.compare(currentPassword, row.password_hash);
      if (!valid) return res.status(400).json({ error: "Incorrect password" });
  
      const newHash = await bcrypt.hash(newPassword, 10);
  
      db.run("UPDATE users SET password_hash = ? WHERE id = ?", [newHash, req.user.id]);
  
      res.json({ updated: true });
    });
  });
  app.post("/api/settings/clear-trusted", authRequired, (req, res) => {
    res.clearCookie("hc_admin_trusted");
    res.json({ cleared: true });
  });
  app.post("/api/settings/reset-2fa", authRequired, (req, res) => {
    db.run("UPDATE users SET twofa_secret=NULL, twofa_enabled=0 WHERE id = ?", [req.user.id]);
    res.json({ reset: true });
  });
  app.post("/api/settings/logout-all", authRequired, (req, res) => {
    res.clearCookie("hc_admin_trusted");
    res.clearCookie("hc_admin_token");
    res.json({ reset: true });
  });
  app.delete("/api/settings/delete-account", authRequired, (req, res) => {
    db.run("DELETE FROM users WHERE id = ?", [req.user.id]);
    res.json({ deleted: true });
  });
  