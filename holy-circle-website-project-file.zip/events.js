// === HOLY CIRCLE EVENTS.JS ===
// Fetches events directly from Google Calendar and shows "Upcoming Highlights"

const eventGrid = document.getElementById("eventGrid");

// === YOUR CALENDAR INFORMATION ===
const CALENDAR_ID = "holycircleorg@gmail.com"; // from your embed link
const API_KEY = "AIzaSyAE4FS8EKWLb6RFNmGhUrYc1bCrBPx0YYk"; // Replace this with your API key

// === GOOGLE CALENDAR API URL ===
const CALENDAR_URL = `https://www.googleapis.com/calendar/v3/calendars/${CALENDAR_ID}/events?key=${API_KEY}&singleEvents=true&orderBy=startTime&timeMin=${new Date().toISOString()}`;

// === LOAD EVENTS ===
async function loadCalendarEvents() {
  try {
    const res = await fetch(CALENDAR_URL);
    const data = await res.json();

    // Filter and sort upcoming events
    const upcomingEvents = (data.items || [])
      .filter(ev => ev.start && (ev.start.date || ev.start.dateTime))
      .sort((a, b) => new Date(a.start.date || a.start.dateTime) - new Date(b.start.date || b.start.dateTime))
      .slice(0, 5); // Show next 5 events

    eventGrid.innerHTML = ""; // Clear old events

    if (upcomingEvents.length === 0) {
      eventGrid.innerHTML = "<p>No upcoming events found.</p>";
      return;
    }

    // === Generate Cards ===
    upcomingEvents.forEach(ev => {
      const title = ev.summary || "Untitled Event";
      const description = ev.description || "";
      const dateStr = ev.start.date || ev.start.dateTime;
      const dateObj = new Date(dateStr);
      const month = dateObj.toLocaleString("default", { month: "short" }).toUpperCase();
      const day = String(dateObj.getDate()).padStart(2, "0");
      const link = ev.htmlLink;

      const card = document.createElement("div");
      card.classList.add("event-card");
      card.innerHTML = `
      <div class="date-box">
        <h3>${month}</h3>
        <span>${day}</span>
      </div>
      <div class="event-info">
        <h3>${title}</h3>
        <p>${description}</p>
        <a href="event-details.html?id=${ev.id}" class="event-btn">More Details</a>

      </div>
    `;
    
      eventGrid.appendChild(card);
    });
  } catch (err) {
    console.error("Error loading calendar events:", err);
    eventGrid.innerHTML = "<p>Unable to load events right now.</p>";
  }
}

// === INITIALIZE ===
loadCalendarEvents();
