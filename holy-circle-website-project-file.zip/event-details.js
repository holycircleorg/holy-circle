const rsvpForm = document.getElementById("rsvpForm");
const rsvpStatus = document.getElementById("rsvpStatus");
const eventTitleField = document.getElementById("eventTitleField");
const eventIdField = document.getElementById("eventIdField");

const params = new URLSearchParams(window.location.search);
const eventId = params.get("id");

const CALENDAR_ID = "holycircleorg@gmail.com";
const API_KEY = "YOUR_GOOGLE_API_KEY";

const URL = `https://www.googleapis.com/calendar/v3/calendars/${CALENDAR_ID}/events/${eventId}?key=${API_KEY}`;

// ELEMENTS
const titleEl = document.getElementById("eventTitle");
const dateEl = document.getElementById("eventDate");
const descEl = document.getElementById("eventDescription");
const locEl = document.getElementById("eventLocation");
const sideDate = document.getElementById("sideDate");
const sideTime = document.getElementById("sideTime");
const googleAdd = document.getElementById("googleAdd");
const appleAdd = document.getElementById("appleAdd");
const outlookAdd = document.getElementById("outlookAdd");
const yahooAdd = document.getElementById("yahooAdd");
const mapContainer = document.getElementById("mapContainer");
const mapFrame = document.getElementById("mapFrame");
const rsvpBtn = document.getElementById("rsvpBtn");

// LOAD EVENT DETAILS
async function loadEvent() {
  const res = await fetch(URL);
  const ev = await res.json();

  eventTitleField.value = ev.summary;
  eventIdField.value = eventId;

  titleEl.textContent = ev.summary;
  descEl.textContent = ev.description || "No description available.";

  // Dates
  const start = new Date(ev.start.dateTime || ev.start.date);
  const end = new Date(ev.end.dateTime || ev.end.date);

  const dateFormatted = start.toLocaleDateString("en-US", {
    weekday:"long", month:"long", day:"numeric", year:"numeric"
  });

  dateEl.textContent = dateFormatted;
  sideDate.textContent = dateFormatted;

  const timeFormatted = start.toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" });
  sideTime.textContent = timeFormatted;

  // Location
  locEl.textContent = ev.location || "Online Event";

  if (ev.location) {
    mapContainer.classList.remove("hidden");
    mapFrame.src = `https://www.google.com/maps?q=${encodeURIComponent(ev.location)}&output=embed`;
  }

  // ADD TO CALENDAR LINKS
  googleAdd.href = ev.htmlLink;

  const ics = `
BEGIN:VCALENDAR
VERSION:2.0
BEGIN:VEVENT
DTSTART:${start.toISOString().replace(/[-:]/g,"").split('.')[0]}Z
DTEND:${end.toISOString().replace(/[-:]/g,"").split('.')[0]}Z
SUMMARY:${ev.summary}
DESCRIPTION:${ev.description || ""}
LOCATION:${ev.location || ""}
END:VEVENT
END:VCALENDAR
  `;

  appleAdd.href = "data:text/calendar;charset=utf-8," + encodeURIComponent(ics);
  outlookAdd.href = appleAdd.href;
  yahooAdd.href = `https://calendar.yahoo.com/?v=60&view=d&type=20&title=${encodeURIComponent(ev.summary)}&st=${start.toISOString().replace(/[-:]/g,"").split('.')[0]}Z&desc=${encodeURIComponent(ev.description || "")}`;

  rsvpBtn.href = ev.htmlLink;
}

loadEvent();


// === RSVP SUBMIT ===
rsvpForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  rsvpStatus.textContent = "Submitting...";
  rsvpStatus.style.color = "#002e6b";

  const payload = {
    name: rsvpForm.rsvpName.value,
    email: rsvpForm.rsvpEmail.value,
    guests: rsvpForm.rsvpGuests.value,
    comments: rsvpForm.rsvpComments.value,
    eventTitle: eventTitleField.value,
    eventId: eventIdField.value
  };

  const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbyJ65kRQnxmAxd3_h6qB9Bd0RiNvMGXjP58YNwDGMhi0I2CtPX26Z53gYgPjNdakGRiAQ/exec";

  try {
    await fetch(SCRIPT_URL, {
      method: "POST",
      body: JSON.stringify(payload)
    });

    rsvpStatus.textContent = "Thank you! Your RSVP has been submitted.";
    rsvpStatus.style.color = "#00a86b";
    rsvpForm.reset();

  } catch (err) {
    rsvpStatus.textContent = "Error submitting RSVP. Please try again.";
    rsvpStatus.style.color = "red";
  }
});
