/************************************
 * RSVP DETAIL PAGE (ADMIN VERSION)
 ************************************/

requireAuth(["owner", "admin"]);

document.getElementById("adminName").textContent =
  localStorage.getItem("adminName") || localStorage.getItem("adminEmail");

// ---- CONFIG ----
const RSVP_API_URL = "https://script.google.com/macros/s/AKfycbyJ65kRQnxmAxd3_h6qB9Bd0RiNvMGXjP58YNwDGMhi0I2CtPX26Z53gYgPjNdakGRiAQ/exec";

// ---- ELEMENTS ----
const params = new URLSearchParams(window.location.search);
const eventId = params.get("id");

const titleEl   = document.getElementById("eventTitle");
const dateEl    = document.getElementById("eventDate");
const locEl     = document.getElementById("eventLocation");
const countEl   = document.getElementById("eventCount");
const exportBtn = document.getElementById("exportBtn");

const rsvpTableBody = document.querySelector("#rsvpTable tbody");
const rsvpEmpty = document.getElementById("rsvpEmpty");

/**
 * Load RSVP Data for this event
 */
async function loadEventRSVPs() {
  try {
    const res = await fetch(`${RSVP_API_URL}?action=event&id=${eventId}`);
    const data = await res.json();

    console.log("RSVP Detail Loaded:", data);

    // Fill event header
    titleEl.textContent = data.title || "(Untitled Event)";
    dateEl.textContent = data.date || "—";
    locEl.textContent = data.location || "—";
    countEl.textContent = data.rsvps?.length || "0";

    // CSV export link
    exportBtn.href = `${RSVP_API_URL}?action=export&id=${eventId}`;

    // Handle no RSVPs
    if (!data.rsvps || data.rsvps.length === 0) {
      rsvpEmpty.classList.remove("hidden");
      return;
    } else {
      rsvpEmpty.classList.add("hidden");
    }

    // Build RSVP table
    rsvpTableBody.innerHTML = "";

    data.rsvps.forEach(r => {
      const tr = document.createElement("tr");

      tr.innerHTML = `
        <td>${r.name}</td>
        <td>${r.email}</td>
        <td>${r.guests || 1}</td>
        <td>${r.comments || ""}</td>
        <td>
          <button 
            class="contacted-btn"
            data-row="${r.row}"
            data-status="${r.contacted || 'NO'}">
            ${r.contacted === "YES" ? "Mark Uncontacted" : "Mark Contacted"}
          </button>
        </td>
      `;

      rsvpTableBody.appendChild(tr);
    });

  } catch (err) {
    console.error("Error loading RSVP details:", err);
    titleEl.textContent = "Error Loading Event";
  }
}

/**
 * Toggle Contacted / Uncontacted
 */
rsvpTableBody.addEventListener("click", async (e) => {
  const btn = e.target.closest(".contacted-btn");
  if (!btn) return;

  const row = btn.getAttribute("data-row");
  const current = btn.getAttribute("data-status");

  const newStatus = current === "YES" ? "NO" : "YES";

  try {
    const res = await fetch(RSVP_API_URL, {
      method: "POST",
      body: JSON.stringify({
        action: "setContacted",
        row: row,
        contacted: newStatus
      })
    });

    const data = await res.json();

    if (data.success) {
      // Update UI
      btn.setAttribute("data-status", newStatus);
      btn.textContent = newStatus === "YES" 
        ? "Mark Uncontacted" 
        : "Mark Contacted";
    }

  } catch (err) {
    console.error("Error updating contacted status:", err);
    alert("Could not update contacted status.");
  }
});

// Load the event
loadEventRSVPs();
