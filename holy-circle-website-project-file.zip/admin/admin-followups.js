// Only owner/admin should see follow-ups
requireAuth(["owner", "admin"]);

document.getElementById("adminName").textContent =
  localStorage.getItem("adminName") || localStorage.getItem("adminEmail");

const PEOPLE_API_URL = "https://script.google.com/macros/s/YOUR_PEOPLE_SCRIPT_ID/exec";

const tableBody = document.querySelector("#followupTable tbody");
const emptyState = document.getElementById("followupEmpty");

let followupList = []; // store loaded follow-up people

// === LOAD FOLLOW-UP LIST ===
async function loadFollowups() {
  try {
    const res = await fetch(PEOPLE_API_URL + "?action=followups");
    const data = await res.json();
    followupList = data.followups || [];

    tableBody.innerHTML = "";

    if (followupList.length === 0) {
      emptyState.classList.remove("hidden");
      return;
    } else {
      emptyState.classList.add("hidden");
    }

    followupList.forEach(person => {
      const tr = document.createElement("tr");

      const stage = person.followStage || "None";

      tr.innerHTML = `
        <td>${person.name}</td>
        <td>
          <span class="status-pill status-${(person.status || "Visitor").toLowerCase()}">
            ${person.status}
          </span>
        </td>
        <td>
          <span class="follow-pill follow-${stage.toLowerCase().replace(/\s+/g,"-")}">
            ${stage}
          </span>
        </td>
        <td>${person.nextFollow}</td>
        <td>${person.tags || ""}</td>
        <td>${person.notes || ""}</td>
        <td>
          <button class="table-btn" data-action="done" data-id="${person.id}">
            Mark Done
          </button>
        </td>
      `;
      tableBody.appendChild(tr);
    });

  } catch (err) {
    console.error("Error loading followups:", err);
    emptyState.textContent = "Error loading follow-up tasks.";
    emptyState.classList.remove("hidden");
  }
}

// === GET FULL PERSON RECORD ===
async function getPersonById(id) {
  try {
    const res = await fetch(PEOPLE_API_URL + "?action=list");
    const data = await res.json();
    const people = data.people || [];
    return people.find(p => String(p.id) === String(id));
  } catch (err) {
    console.error("Error fetching person:", err);
    return null;
  }
}

// === MARK FOLLOW-UP DONE ===
async function markFollowupDone(personId) {
  const person = await getPersonById(personId);
  if (!person) {
    alert("Unable to load person details.");
    return;
  }

  // Create updated payload
  const payload = {
    id: person.id,
    name: person.name,
    email: person.email,
    phone: person.phone,
    status: person.status,
    followStage: "None",        // Clear follow-up stage
    nextFollow: "",             // Clear next-follow date
    tags: person.tags,
    notes: person.notes
  };

  try {
    // Save updated person
    await fetch(PEOPLE_API_URL, {
      method: "POST",
      body: JSON.stringify({
        action: "save",
        person: payload
      })
    });

    // Log to timeline: "Follow-up completed"
    await fetch(PEOPLE_API_URL, {
      method: "POST",
      body: JSON.stringify({
        action: "log",
        email: person.email,
        name: person.name,
        text: "Follow-up completed",
      })
    });

    // Refresh list
    await loadFollowups();

  } catch (err) {
    console.error("Error marking follow-up done:", err);
    alert("Error marking follow-up done.");
  }
}

// === ACTION HANDLER ===
tableBody.addEventListener("click", async (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;

  const id = btn.getAttribute("data-id");
  const action = btn.getAttribute("data-action");

  if (action === "done") {
    await markFollowupDone(id);
  }
});
