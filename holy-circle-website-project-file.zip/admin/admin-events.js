// SIMPLE SAMPLE DATA
let events = [
    {
      id: 1,
      name: "Holy Circle Worship Night",
      date: "2025-12-05",
      time: "18:30",
      location: "Holy Circle HQ",
      type: "worship",
      status: "upcoming",
      rsvps: 82,
      total: 95
    }
  ];
  
  const tableBody = document.getElementById("eventsTableBody");
  const emptyState = document.getElementById("eventsEmptyState");
  
  function renderEvents() {
    tableBody.innerHTML = "";
  
    if (events.length === 0) {
      emptyState.classList.remove("hidden");
      return;
    }
  
    emptyState.classList.add("hidden");
  
    events.forEach(ev => {
      const tr = document.createElement("tr");
  
      tr.innerHTML = `
        <td>${ev.name}</td>
        <td>${ev.date} @ ${ev.time}</td>
        <td>${ev.location}</td>
        <td>${ev.rsvps} / ${ev.total}</td>
        <td><span class="status-badge status-${ev.status}">${ev.status}</span></td>
        <td><button class="secondary-btn">Edit</button></td>
      `;
  
      tableBody.appendChild(tr);
    });
  }
  
  renderEvents();
  
  // MODAL
  const modal = document.getElementById("eventModal");
  const openModalBtn = document.getElementById("openCreateModal");
  const closeModalBtn = document.getElementById("closeModal");
  
  openModalBtn.onclick = () => modal.classList.add("active");
  closeModalBtn.onclick = () => modal.classList.remove("active");
  
  modal.onclick = e => {
    if (e.target === modal) modal.classList.remove("active");
  };
  