const API_BASE = "http://localhost:4000/api";

async function loginAdmin(email, password, twofaCode = null) {
  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, twofaCode }),
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || "Login failed");
    }

    if (data.twofaRequired) {
      return { twofaRequired: true };
    }

    localStorage.setItem("hc_admin_user", JSON.stringify(data.user));
    return { success: true };
  } catch (err) {
    console.error(err);
    return { success: false, error: err.message };
  }
}

async function fetchCurrentAdmin() {
  try {
    const res = await fetch(`${API_BASE}/auth/me`, {
      credentials: "include",
    });
    if (!res.ok) return null;
    const data = await res.json();
    localStorage.setItem("hc_admin_user", JSON.stringify(data.user));
    return data.user;
  } catch (e) {
    return null;
  }
}

async function requireAdmin() {
  let user = JSON.parse(localStorage.getItem("hc_admin_user") || "null");
  if (!user) {
    user = await fetchCurrentAdmin();
  }
  if (!user) {
    window.location.href = "admin-login.html";
  } else {
    const nameEl = document.getElementById("adminName");
    const roleEl = document.getElementById("adminRole");
    if (nameEl) nameEl.textContent = user.name || user.email;
    if (roleEl) roleEl.textContent = user.role || "Admin";
  }
}

async function logoutAdmin() {
  try {
    await fetch(`${API_BASE}/auth/logout`, {
      method: "POST",
      credentials: "include",
    });
  } catch (e) {}
  localStorage.removeItem("hc_admin_user");
  window.location.href = "admin-login.html";
}
