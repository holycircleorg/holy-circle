// Only allow owner & admin to manage people (you can add roles)
requireAuth(["owner", "admin"]);

document.getElementById("adminName").textContent =
  localStorage.getItem("adminName") || localStorage.getItem("adminEmail");

// === CONFIG: People API (separate Apps Script Web App) ===
const PEOPLE_API_URL = "https://script.google.com/macros/s/AKfycbznpagLHNJAJsvltz1eKHkRPHKIkA8j0o6ynCn4XQgmKYUgclpTXc4hp0r9E3y8tX4c1Q/exec";

// Elements
const peopleTableBody = document.querySelector("#peopleTable tbody");
const peopleEmptyState = document.getElementById("peopleEmptyState");
const peopleSearch = document.getElementById("peopleSearch");
const statusFilter = document.getElementById("statusFilter");

const personFormPanel = document.getElementById("personFormPanel");
const personForm = document.getElementById("personForm");
const personFormTitle = document.getElementById("personFormTitle");
const personFormStatus = document.getElementById("personFormStatus");
const newPersonBtn = document.getElementById("newPersonBtn");
const cancelPersonBtn = document.getElementById("cancelPersonBtn");

let people = []; // full list from backend

// === UI HELPERS ===
function openPersonForm(editMode = false, person = null) {
  personFormPanel.classList.remove("hidden");
  personFormStatus.textContent = "";

  if (editMode && person) {
    personFormTitle.textContent = "Edit Person";
    document.getElementById("personId").value = person.id;
    document.getElementById("personName").value = person.name || "";
    document.getElementById("personEmail").value = person.email || "";
    document.getElementById("personPhone").value = person.phone || "";
    document.getElementById("personStatus").value = person.status || "Visitor";
    document.getElementById("personTags").value = person.tags || "";
    document.getElementById("personNotes").value = person.notes || "";
  } else {
    personFormTitle.textContent = "Add Person";
    personForm.reset();
    document.getElementById("personId").value = "";
  }
}

function closePersonForm() {
  personFormPanel.classList.add("hidden");
}

// === RENDER TABLE ===
function renderPeople(filteredList) {
  peopleTableBody.innerHTML = "";

  if (!filteredList || filteredList.length === 0) {
    peopleEmptyState.classList.remove("hidden");
    return;
  } else {
    peopleEmptyState.classList.add("hidden");
  }

  filteredList.forEach(person => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${person.name || ""}</td>
      <td>${person.email || ""}</td>
      <td>${person.phone || ""}</td>
      <td><span class="status-pill status-${(person.status || "Visitor").toLowerCase()}">${person.status || "Visitor"}</span></td>
      <td>${person.tags || ""}</td>
      <td>${person.lastActivity || ""}</td>
      <td>
        <button class="table-btn" data-action="edit" data-id="${person.id}">Edit</button>
        <button class="table-btn danger" data-action="delete" data-id="${person.id}">Delete</button>
      </td>
    `;

    peopleTableBody.appendChild(tr);
  });
}

// === FILTERING ===
function applyFilters() {
  const q = (peopleSearch.value || "").toLowerCase();
  const status = statusFilter.value;

  const filtered = people.filter(p => {
    const matchesSearch =
      (p.name || "").toLowerCase().includes(q) ||
      (p.email || "").toLowerCase().includes(q) ||
      (p.tags || "").toLowerCase().includes(q);

    const matchesStatus =
      status === "all" || (p.status || "Visitor") === status;

    return matchesSearch && matchesStatus;
  });

  renderPeople(filtered);
}

// === LOAD PEOPLE FROM BACKEND ===
async function loadPeople() {
  try {
    const res = await fetch(PEOPLE_API_URL + "?action=list");
    const data = await res.json();
    people = data.people || [];
    applyFilters();
  } catch (err) {
    console.error("Error loading people:", err);
    peopleEmptyState.textContent = "Error loading people. Check your API.";
    peopleEmptyState.classList.remove("hidden");
  }
}

// === SAVE PERSON (CREATE / UPDATE) ===
personForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  personFormStatus.textContent = "Saving...";
  personFormStatus.style.color = "#002e6b";

  const payload = {
    id: document.getElementById("personId").value || null,
    name: document.getElementById("personName").value.trim(),
    email: document.getElementById("personEmail").value.trim(),
    phone: document.getElementById("personPhone").value.trim(),
    status: document.getElementById("personStatus").value,
    tags: document.getElementById("personTags").value.trim(),
    notes: document.getElementById("personNotes").value.trim(),
  };

  try {
    await fetch(PEOPLE_API_URL, {
      method: "POST",
      body: JSON.stringify({ action: "save", person: payload }),
    });

    personFormStatus.textContent = "Saved.";
    personFormStatus.style.color = "#00a86b";
    await loadPeople();
    setTimeout(closePersonForm, 600);

  } catch (err) {
    console.error(err);
    personFormStatus.textContent = "Error saving. Please retry.";
    personFormStatus.style.color = "red";
  }
});

// === DELETE PERSON ===
peopleTableBody.addEventListener("click", async (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;

  const id = btn.getAttribute("data-id");
  const action = btn.getAttribute("data-action");
  const person = people.find(p => String(p.id) === String(id));

  if (action === "edit" && person) {
    openPersonForm(true, person);
  }

  if (action === "delete" && person) {
    if (!confirm(`Delete ${person.name}?`)) return;

    try {
      await fetch(PEOPLE_API_URL, {
        method: "POST",
        body: JSON.stringify({ action: "delete", id })
      });
      await loadPeople();
    } catch (err) {
      console.error(err);
      alert("Error deleting person. Check console.");
    }
  }
});

// === UI HOOKS ===
newPersonBtn.addEventListener("click", () => openPersonForm(false));
cancelPersonBtn.addEventListener("click", closePersonForm);

peopleSearch.addEventListener("input", applyFilters);
statusFilter.addEventListener("change", applyFilters);

// Initial load
loadPeople();
