// Require owner or admin to access the dashboard
requireAuth(["owner", "admin"]);

// Show admin name + role
const adminNameEl = document.getElementById("adminName");
const adminRoleEl = document.getElementById("adminRole");

adminNameEl.textContent =
  localStorage.getItem("adminName") || localStorage.getItem("adminEmail") || "Admin";

const role = localStorage.getItem("adminRole") || "admin";
adminRoleEl.textContent = role.replace("-", " ").toUpperCase();


// ===== SAMPLE DATA (REPLACE WITH REAL LATER) =====
const sampleStats = {
  people: 142,
  donors: 27,
  eventsThisMonth: 5,
  monthlyGiving: 4230
};

const sampleWeekEvents = [
  { day: "Tue", name: "Podcast Recording: Faith Unfiltered", time: "7:00 PM" },
  { day: "Thu", name: "Team Meeting: Holy Circle News", time: "6:00 PM" },
  { day: "Sat", name: "Community Outreach Night", time: "5:30 PM" },
];

const sampleTasks = [
  { label: "Follow up with new visitor from last event", owner: "Charles", due: "Today" },
  { label: "Send donation receipts for October", owner: "Treasurer", due: "Tomorrow" },
  { label: "Confirm volunteers for Saturday outreach", owner: "Tyler", due: "2 days" },
  { label: "Schedule next podcast guest", owner: "Media Team", due: "This week" },
];

const sampleNotifs = [
  { type: "rsvp", text: "New RSVP for Community Outreach Night", time: "2 min ago" },
  { type: "donation", text: "New gift: $250 from Anonymous Donor", time: "20 min ago" },
  { type: "people", text: "New profile created: Jordan M.", time: "1 hour ago" },
  { type: "news", text: "Draft article ready: 'Faith & Culture Roundup'", time: "3 hours ago" },
];


// ===== FILL STATS =====
function loadStats() {
  document.getElementById("statPeople").textContent = sampleStats.people;
  document.getElementById("statDonors").textContent = sampleStats.donors;
  document.getElementById("statEvents").textContent = sampleStats.eventsThisMonth;
  document.getElementById("statDonations").textContent = `$${sampleStats.monthlyGiving.toLocaleString()}`;
}


// ===== FILL THIS WEEK =====
function loadWeekEvents() {
  const list = document.getElementById("weekEvents");
  list.innerHTML = "";

  sampleWeekEvents.forEach(ev => {
    const li = document.createElement("li");
    li.innerHTML = `
      <div class="list-main">
        <span class="list-title">${ev.name}</span>
        <span class="list-meta">${ev.day} · ${ev.time}</span>
      </div>
    `;
    list.appendChild(li);
  });
}


// ===== FILL TASKS =====
function loadTasks() {
  const list = document.getElementById("taskList");
  list.innerHTML = "";

  sampleTasks.forEach(task => {
    const li = document.createElement("li");
    li.innerHTML = `
      <div class="list-main">
        <span class="list-title">${task.label}</span>
        <span class="list-meta">Owner: ${task.owner} · Due: ${task.due}</span>
      </div>
      <button class="small-btn">Mark Done</button>
    `;
    list.appendChild(li);
  });
}


// ===== FILL NOTIFICATIONS =====
function loadNotifications() {
  const list = document.getElementById("notifList");
  list.innerHTML = "";

  sampleNotifs.forEach(n => {
    const li = document.createElement("li");
    li.innerHTML = `
      <div class="list-main">
        <span class="list-title">${iconForType(n.type)} ${n.text}</span>
        <span class="list-meta">${n.time}</span>
      </div>
    `;
    list.appendChild(li);
  });
}

function iconForType(type) {
  if (type === "rsvp") return `<i class="fa-solid fa-ticket"></i>`;
  if (type === "donation") return `<i class="fa-solid fa-hand-holding-dollar"></i>`;
  if (type === "people") return `<i class="fa-solid fa-user"></i>`;
  if (type === "news") return `<i class="fa-solid fa-newspaper"></i>`;
  return `<i class="fa-solid fa-circle-info"></i>`;
}


// ===== CHARTS =====
function setupCharts() {
  const donationCtx = document.getElementById("donationChart");
  const rsvpCtx = document.getElementById("rsvpChart");

  new Chart(donationCtx, {
    type: "line",
    data: {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
      datasets: [{
        label: "Donations ($)",
        data: [500, 1200, 800, 2400, 1900, 2600],
        borderColor: "#bf9745",
        backgroundColor: "rgba(191,151,69,0.2)",
        tension: 0.3,
      }]
    },
    options: {
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: { beginAtZero: true }
      }
    }
  });

  new Chart(rsvpCtx, {
    type: "bar",
    data: {
      labels: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      datasets: [{
        label: "RSVPs This Week",
        data: [12, 8, 16, 10, 22, 28, 15],
        backgroundColor: "#002e6b"
      }]
    },
    options: {
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: { beginAtZero: true }
      }
    }
  });
}


// ===== INIT =====
loadStats();
loadWeekEvents();
loadTasks();
loadNotifications();
setupCharts();

/* ================================
   LOAD NOTIFICATIONS
================================ */

const PEOPLE_API_URL = "https://script.google.com/macros/s/YOUR_PEOPLE_SCRIPT_ID/exec";
const RSVP_API_URL = "https://script.google.com/macros/s/YOUR_RSVP_SCRIPT_ID/exec";
const DONATION_API_URL = "https://script.google.com/macros/s/YOUR_DONATIONS_SCRIPT_ID/exec";

const notificationsList = document.getElementById("notificationsList");
const noNotifications = document.getElementById("noNotifications");

async function loadNotifications() {
  
  const notifications = [];

  /* 1. Overdue Follow-Ups */
  try {
    const resFollow = await fetch(PEOPLE_API_URL + "?action=followups");
    const dataFollow = await resFollow.json();
    const overdue = dataFollow.followups || [];

    overdue.forEach(p => {
      notifications.push({
        type: "followup",
        icon: "fa-phone",
        text: `${p.name} needs a follow-up (${p.followStage}).`,
      });
    });
  } catch (err) {
    console.error("Follow-up error:", err);
  }

  /* 2. New RSVPs */
  try {
    const resRSVP = await fetch(RSVP_API_URL + "?action=new");
    const dataRSVP = await resRSVP.json();
    (dataRSVP.newRSVPs || []).forEach(r => {
      notifications.push({
        type: "rsvp",
        icon: "fa-calendar-check",
        text: `${r.name} RSVP’d to ${r.eventTitle}.`,
      });
    });
  } catch (err) {
    console.error("RSVP error:", err);
  }

  /* 3. New Donors */
  try {
    const resDon = await fetch(DONATION_API_URL + "?action=new");
    const dataDon = await resDon.json();
    (dataDon.newDonations || []).forEach(d => {
      notifications.push({
        type: "donation",
        icon: "fa-hand-holding-heart",
        text: `${d.name} donated $${d.amount} to ${d.campaign}.`,
      });
    });
  } catch (err) {
    console.error("Donation error:", err);
  }

  /* 4. Upcoming Events */
  try {
    const resEvents = await fetch(RSVP_API_URL + "?action=upcoming");
    const dataEvents = await resEvents.json();
    (dataEvents.events || []).forEach(ev => {
      notifications.push({
        type: "event",
        icon: "fa-calendar-day",
        text: `Upcoming event: ${ev.title} on ${ev.date}.`,
      });
    });
  } catch (err) {
    console.error("Upcoming event error:", err);
  }

  /* Render notifications */
  notificationsList.innerHTML = "";

  if (notifications.length === 0) {
    noNotifications.classList.remove("hidden");
    return;
  }

  noNotifications.classList.add("hidden");

  notifications.forEach(n => {
    const div = document.createElement("div");
    div.className = `notification-card notification-${n.type}`;
    div.innerHTML = `
      <i class="fa-solid ${n.icon}"></i>
      <p>${n.text}</p>
    `;
    notificationsList.appendChild(div);
  });
}

loadNotifications();
setInterval(loadNotifications, 30000); // Auto-refresh every 30 seconds
