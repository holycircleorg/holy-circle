// Lock page to owner/admin
requireAuth(["owner", "admin"]);

document.getElementById("adminName").textContent =
  localStorage.getItem("adminName") || localStorage.getItem("adminEmail");

// Donations API
const DONATIONS_API_URL = "https://script.google.com/macros/s/AKfycbyL-APnNTb8cqjCRX8wsKppfOTImGOFrpHM4Luj9eIXJX-GsJFXCiStkph-6szE-cxP/exec";

const donorsTableBody   = document.querySelector("#donorsTable tbody");
const donorsEmptyState  = document.getElementById("donorsEmptyState");
const donorSearch       = document.getElementById("donorSearch");
const minTotalFilter    = document.getElementById("minTotalFilter");

const donorsCountEl     = document.getElementById("donorsCount");
const donorsTotalEl     = document.getElementById("donorsTotal");
const donorsYearTotalEl = document.getElementById("donorsYearTotal");

let donors = []; // aggregated donors

// Format currency
function fmtCurrency(x) {
  return "$" + Number(x || 0).toLocaleString(undefined, {minimumFractionDigits: 0});
}

function fmtDate(d) {
  if (!d) return "";
  try {
    return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  } catch {
    return d;
  }
}

// Build donors from donation list
async function loadDonors() {
  try {
    const res = await fetch(DONATIONS_API_URL + "?action=list");
    const data = await res.json();
    const donations = data.donations || [];

    const map = {};
    const thisYear = new Date().getFullYear();
    let totalAll = 0;
    let totalYear = 0;

    donations.forEach(d => {
      const email = (d.email || "").toLowerCase();
      if (!email) return;

      if (!map[email]) {
        map[email] = {
          name: d.name || "(No name)",
          email: d.email,
          total: 0,
          count: 0,
          lastDate: null,
          lastAmount: 0,
          campaigns: new Set()
        };
      }

      const donor = map[email];
      const amt = Number(d.amount) || 0;
      donor.total += amt;
      donor.count += 1;
      donor.campaigns.add(d.campaign || "General");

      const giftDate = d.date ? new Date(d.date) : null;
      if (!donor.lastDate || (giftDate && giftDate > donor.lastDate)) {
        donor.lastDate = giftDate;
        donor.lastAmount = amt;
      }

      totalAll += amt;
      if (giftDate && giftDate.getFullYear() === thisYear) {
        totalYear += amt;
      }
    });

    donors = Object.values(map);

    donorsCountEl.textContent = donors.length;
    donorsTotalEl.textContent = fmtCurrency(totalAll);
    donorsYearTotalEl.textContent = fmtCurrency(totalYear);

    applyFilters();

  } catch (err) {
    console.error("Error loading donors:", err);
    donorsEmptyState.textContent = "Error loading donors. Check your Donations API.";
    donorsEmptyState.classList.remove("hidden");
  }
}

function renderDonors(list) {
  donorsTableBody.innerHTML = "";

  if (!list || list.length === 0) {
    donorsEmptyState.classList.remove("hidden");
    return;
  } else {
    donorsEmptyState.classList.add("hidden");
  }

  list.forEach(donor => {
    const tr = document.createElement("tr");

    const campaignList = Array.from(donor.campaigns || []).join(", ");
    const lastGiftStr = donor.lastDate
      ? `${fmtCurrency(donor.lastAmount)} on ${fmtDate(donor.lastDate)}`
      : "";

    tr.innerHTML = `
      <td>${donor.name}</td>
      <td>${donor.email}</td>
      <td>${fmtCurrency(donor.total)}</td>
      <td>${donor.count}</td>
      <td>${lastGiftStr}</td>
      <td>${campaignList}</td>
      <td>
        <button class="table-btn" data-email="${donor.email}">
          View
        </button>
      </td>
    `;

    donorsTableBody.appendChild(tr);
  });
}

function applyFilters() {
  const q = (donorSearch.value || "").toLowerCase();
  const minTotal = Number(minTotalFilter.value || 0);

  const filtered = donors.filter(d => {
    const matchesSearch =
      (d.name || "").toLowerCase().includes(q) ||
      (d.email || "").toLowerCase().includes(q) ||
      Array.from(d.campaigns || []).join(", ").toLowerCase().includes(q);

    const matchesTotal = d.total >= minTotal;

    return matchesSearch && matchesTotal;
  });

  renderDonors(filtered);
}

// Events
donorSearch.addEventListener("input", applyFilters);
minTotalFilter.addEventListener("change", applyFilters);

donorsTableBody.addEventListener("click", (e) => {
  const btn = e.target.closest("button.table-btn");
  if (!btn) return;

  const email = btn.getAttribute("data-email");
  if (!email) return;

  // Go to donor details page
  window.location.href = `admin-donor-details.html?email=${encodeURIComponent(email)}`;
});

// Initial load
loadDonors();
